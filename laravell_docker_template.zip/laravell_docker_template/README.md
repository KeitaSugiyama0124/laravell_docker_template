# laravell_docker_template

using step

1. clone download
2. change current directory to docker-project directory
3. put this command

```
docker-compose up -d
```

- environment

```
port: 80
sql port : 33306

php: 8.0
mysql: 8.0
Laravell : lateast

docker-compose.yml version : 3.3
web engine: nginx fastcgi
```
